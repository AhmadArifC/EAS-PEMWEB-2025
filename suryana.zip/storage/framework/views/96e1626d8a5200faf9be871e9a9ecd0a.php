<form method="POST" action="<?php echo e(route('profile.destroy')); ?>"
    onsubmit="return confirm('Yakin ingin menghapus akun Anda?');">
    <?php echo csrf_field(); ?>
    <?php echo method_field('DELETE'); ?>

    <p class="text-danger">Akun Anda akan dihapus secara permanen beserta semua data yang terkait.</p>

    <div class="form-group mt-3">
        <form action="<?php echo e(route('users.destroy', $user->id)); ?>" method="POST" class="d-inline">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" class="btn btn-sm btn-danger btn-delete-confirm">
                <i class="fas fa-user-slash"></i> Hapus Akun
            </button>
        </form>
    </div>
</form>
<?php /**PATH D:\Framework Project Laravel\Pemweb-EAS\resources\views/profile/partials/delete-user-form.blade.php ENDPATH**/ ?>