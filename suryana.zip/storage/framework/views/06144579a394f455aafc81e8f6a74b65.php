<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('header', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <!-- Total Produk -->
        <div class="col-md-3 col-sm-6">
            <div class="info-box bg-info">
                <span class="info-box-icon"><i class="fas fa-boxes"></i></span>
                <div class="info-box-content">
                    <span class="info-box-text">Produk</span>
                    <span class="info-box-number"><?php echo e($productsCount); ?></span>
                    <a href="<?php echo e(route('products.index')); ?>" class="small-box-footer text-white">
                        More info <i class="fas fa-arrow-circle-right"></i>
                    </a>
                </div>
            </div>
        </div>

        <!-- Total Kategori -->
        <div class="col-md-3 col-sm-6">
            <div class="info-box bg-success">
                <span class="info-box-icon"><i class="fas fa-tags"></i></span>
                <div class="info-box-content">
                    <span class="info-box-text">Kategori</span>
                    <span class="info-box-number"><?php echo e($categoriesCount); ?></span>
                    <a href="<?php echo e(route('categories.index')); ?>" class="small-box-footer text-white">
                        More info <i class="fas fa-arrow-circle-right"></i>
                    </a>
                </div>
            </div>
        </div>

        <!-- Total User -->
        <div class="col-md-3 col-sm-6">
            <div class="info-box bg-warning">
                <span class="info-box-icon"><i class="fas fa-users"></i></span>
                <div class="info-box-content">
                    <span class="info-box-text">Pengguna</span>
                    <span class="info-box-number"><?php echo e($usersCount); ?></span>
                    <a href="<?php echo e(route('users.index')); ?>" class="small-box-footer text-white">
                        More info <i class="fas fa-arrow-circle-right"></i>
                    </a>
                </div>
            </div>
        </div>

        <!-- Stok Rendah -->
        <div class="col-md-3 col-sm-6">
            <div class="info-box bg-danger">
                <span class="info-box-icon"><i class="fas fa-exclamation-triangle"></i></span>
                <div class="info-box-content">
                    <span class="info-box-text">Stok Rendah</span>
                    <span class="info-box-number"><?php echo e($lowStockCount); ?></span>
                    <a href="<?php echo e(route('products.index')); ?>" class="small-box-footer text-white">
                        More info <i class="fas fa-arrow-circle-right"></i>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Produk Hampir Habis -->
    <div class="card mt-4">
        <div class="card-header">
            <h5>Stok Hampir Habis</h5>
        </div>
        <div class="card-body">
            <?php if($lowStockProducts->count()): ?>
                <ul class="list-group">
                    <?php $__currentLoopData = $lowStockProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <?php echo e($product->name); ?>

                            <span class="badge bg-danger rounded-pill"><?php echo e($product->stock); ?> tersisa</span>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php else: ?>
                <p class="text-muted">Semua stok masih aman.</p>
            <?php endif; ?>
        </div>
    </div>

    <!-- Aktivitas Terakhir -->
    <div class="card mt-4">
        <div class="card-header bg-info">
            <h3 class="card-title text-white"><i class="fas fa-history"></i> Aktivitas Terakhir</h3>
        </div>
        <div class="card-body">
            <ul class="list-group">
                <?php $__empty_1 = true; $__currentLoopData = $recentActivities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <li class="list-group-item">
                        <strong><?php echo e($activity->user->name ?? 'Guest'); ?></strong> <em><?php echo e($activity->action); ?></em>
                        <?php if($activity->subject_type): ?>
                            pada <strong><?php echo e(class_basename($activity->subject_type)); ?></strong> ID:
                            <?php echo e($activity->subject_id); ?>

                        <?php endif; ?>
                        <br><small class="text-muted"><?php echo e($activity->created_at->diffForHumans()); ?></small>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <li class="list-group-item text-muted">Belum ada aktivitas tercatat.</li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Framework Project Laravel\Pemweb-EAS\resources\views/dashboard.blade.php ENDPATH**/ ?>