<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH D:\Framework Project Laravel\Pemweb-EAS\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php ENDPATH**/ ?>