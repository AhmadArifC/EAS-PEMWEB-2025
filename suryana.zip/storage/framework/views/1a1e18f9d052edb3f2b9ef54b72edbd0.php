<?php echo e($slot); ?>

<?php /**PATH D:\Framework Project Laravel\Pemweb-EAS\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>