<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Suryana Project</title>
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=instrument-sans:400,500,600" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" />
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>

<body class="bg-gray-50 min-h-screen flex flex-col">

    
    <header class="bg-white shadow-md">
        <div class="max-w-7xl mx-auto px-6 py-5 flex items-center justify-between">
            <div class="flex items-center">
                <img src="<?php echo e(asset('images/suryana_logo.png')); ?>" alt="Logo"
                    class="w-10 h-10 rounded-full shadow-sm">
                <span class="ml-3 text-2xl font-extrabold text-indigo-600">Suryana Project</span>
            </div>
            <div class="flex items-center space-x-3">
                <?php if(Route::has('login')): ?>
                    <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(url('/dashboard')); ?>"
                            class="bg-indigo-600 text-white px-4 py-2 rounded-lg shadow hover:bg-indigo-700 transition">
                            Dashboard
                        </a>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>"
                            class="border border-indigo-600 text-indigo-600 px-4 py-2 rounded-lg hover:bg-indigo-600 hover:text-white transition">
                            Login
                        </a>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </header>

    
    <main class="flex-1 max-w-7xl mx-auto px-6 py-12">

        
        <form method="GET" action="<?php echo e(url('/')); ?>" class="flex flex-col md:flex-row gap-4 mb-12">
            <input name="search" value="<?php echo e(request('search')); ?>"
                placeholder="Cari produk berdasarkan nama atau kategori..."
                class="flex-1 px-5 py-3 border border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-indigo-400 focus:outline-none"
                id="search" />
            <button type="submit"
                class="inline-flex items-center gap-2 bg-indigo-600 text-white px-6 py-3 rounded-lg shadow hover:bg-indigo-700 transition">
                <i class="fas fa-search"></i> Cari
            </button>
        </form>

        
        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8">
            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div
                    class="bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transform hover:-translate-y-1 transition">
                    <div class="h-40 bg-gray-100 flex items-center justify-center">
                        <?php if($product->image): ?>
                            <img src="<?php echo e(asset('storage/' . $product->image)); ?>" alt="<?php echo e($product->name); ?>"
                                class="h-full object-cover" />
                        <?php else: ?>
                            <i class="fas fa-box-open text-gray-300 text-5xl"></i>
                        <?php endif; ?>
                    </div>
                    <div class="p-5">
                        <h2 class="font-semibold text-xl mb-2"><?php echo e($product->name); ?></h2>
                        <p class="text-sm text-gray-500 mb-3">
                            Kategori: <span class="font-medium"><?php echo e($product->category->name ?? '–'); ?></span>
                        </p>
                        
                        <div class="text-indigo-600 font-bold text-lg mb-1">
                            Rp <?php echo e(number_format($product->price, 0, ',', '.')); ?>

                        </div>
                        
                        <div class="text-sm text-gray-600">
                            Stok: <?php echo e($product->stock); ?>

                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col-span-full text-center text-gray-500 py-12">
                    Belum ada produk tersedia.
                </div>
            <?php endif; ?>
        </div>

        
        <div class="mt-10">
            <?php echo e($products->withQueryString()->links()); ?>

        </div>
    </main>

    
    <footer class="bg-white border-t mt-auto">
        <div class="max-w-7xl mx-auto px-6 py-6 text-center text-gray-500 text-sm">
            &copy; <?php echo e(date('Y')); ?> Suryana Project. All rights reserved.
        </div>
    </footer>

    
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const searchInput = document.getElementById('search');
            document.addEventListener('mousedown', (e) => {
                if (searchInput && !searchInput.contains(e.target)) {
                    searchInput.blur();
                }
            });
        });
    </script>
</body>

</html>
<?php /**PATH D:\Framework Project Laravel\Pemweb-EAS\resources\views/welcome.blade.php ENDPATH**/ ?>