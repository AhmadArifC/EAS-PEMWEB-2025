<img src="{{ asset('images/suryana_logo.png') }}" alt="Logo" {{ $attributes }}>
